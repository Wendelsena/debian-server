--
-- PostgreSQL database dump
--

\restrict SVHFp639eSEFrvQ6TkgvBeQptbqWNMZQCajMw6mtrY0L9gshIY3vlIpyNzAVfk1

-- Dumped from database version 17.10 (Debian 17.10-1.pgdg13+1)
-- Dumped by pg_dump version 17.10 (Debian 17.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: medicos; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.medicos (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    especialidade character varying(100),
    crm character varying(20),
    ativo boolean DEFAULT true,
    criado_em timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.medicos OWNER TO admin;

--
-- Name: medicos_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.medicos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.medicos_id_seq OWNER TO admin;

--
-- Name: medicos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.medicos_id_seq OWNED BY public.medicos.id;


--
-- Name: medicos id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.medicos ALTER COLUMN id SET DEFAULT nextval('public.medicos_id_seq'::regclass);


--
-- Data for Name: medicos; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.medicos (id, nome, especialidade, crm, ativo, criado_em) FROM stdin;
1	João Silva	Cardiologia	CRM12345	t	2026-07-01 19:08:45.879771
2	Maria Souza	Pediatria	CRM22334	t	2026-07-01 19:08:45.879771
3	Carlos Lima	Ortopedia	CRM99887	t	2026-07-01 19:08:45.879771
4	Fernanda Alves	Neurologia	CRM88776	t	2026-07-01 19:08:45.879771
5	Juliana Costa	Clínica Geral	CRM55555	t	2026-07-01 19:08:45.879771
\.


--
-- Name: medicos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.medicos_id_seq', 5, true);


--
-- Name: medicos medicos_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.medicos
    ADD CONSTRAINT medicos_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict SVHFp639eSEFrvQ6TkgvBeQptbqWNMZQCajMw6mtrY0L9gshIY3vlIpyNzAVfk1

